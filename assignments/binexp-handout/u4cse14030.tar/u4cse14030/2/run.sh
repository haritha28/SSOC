#!/bin/sh
python payload.py > exploit.txt


