#!/bin/sh
 python exploit.py > exploit.txt

