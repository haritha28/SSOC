In Function one we are moving the current path to r9.
Moves the value in rsp to rdx and does an and operation on it.
